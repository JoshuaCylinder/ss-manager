class ConflictPortException(Exception):
    pass


class UserNotFoundError(Exception):
    pass
